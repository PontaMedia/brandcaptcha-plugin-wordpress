== For Translators ==

Note: this folder contains MO files, PO files and POT file.

If you have created your own translation, or have an update of an existing one, please send it to Soporte Pontamedia <soporte@pontamedia.com> so that I can bundle it into the next release of the plugin.

Thank you.